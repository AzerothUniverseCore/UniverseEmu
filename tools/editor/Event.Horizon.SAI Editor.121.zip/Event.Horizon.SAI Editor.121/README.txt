 _                               
|_   _ ._ _|_  |_| _ ._ o_  _ ._ 
|_\/(/_| | |_  | |(_)|  |/_(_)| |
- ------------------------------- -
	Event Horizon is a development tool for SmartAI (SAI).
	It is was initially written for TrinityCore and Project Skyfire but it can work on any other core which supports SAI.
- ------------------------------- -
	If you need any help or tutorials visit:
	http://devsource-eventhorizon.tk/  	(temporary)
- ------------------------------- -
	Required Softwares:
	- Java 2 SE Runtime Environment (www.java.com)
- ------------------------------- -